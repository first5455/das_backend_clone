from api.views.KubernetesAllPodView import kubernetesAllPodView
from api.views.UserView import RegisterView
